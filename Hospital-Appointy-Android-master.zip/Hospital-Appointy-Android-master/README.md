# Hospital Appointy

This is a Hospital Online Booking Appointment Application.

App Features:

*   Visitor Can search for appointment 
      by - Date , Specialization , Doctor.
                      
*   Patient can search , book & cancel an Appointment and can 
              see the doctor profile & booked appointment.
              
*   Doctor can use this app to see the booked appointments of patient
               and dotor can also update his profile through this app.
               
# Demo of App

 <img src="https://github.com/amankumar367/HospitalAppointy/blob/master/Screenshots/Hospital_Appointy.gif">
